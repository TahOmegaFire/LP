Integrantes:
- Daniel Bornscheuer, Rol: 201773518-K
- Guillermo Vásquez, Rol: 201773552-K

El programa se compila corriendo el comando MAKE en la carpeta en donde se encuentra este README. La compilación espera que exista un archivo de código fuente C llamado main.c ubicado en la carpeta src/, donde el programa principal se deberá encontrar. El binario se encontrará listo para la ejecución en la carpeta bin/.

Para el correcto funcionamiento del programa, en genetico.c se debe editar la función int valor(void*), que deberá ser la función que retorne un valor entero según como se evalúe la lista pasada.

Se sugiere añadir srand(time(NULL)) en main.c para valores aleatorios.
